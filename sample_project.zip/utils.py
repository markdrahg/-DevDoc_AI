def greet():
    return "Hello"
